

/**
 * Represents RGB colors.
 * RGB values are stored in a 3-position array, with values in the interval [0, 255].
 * rgb[0] - Red
 * rgb[1] - Green
 * rgb[2] - Blue
 */

class Color {

	private final int[] rgb; // @color

	/**
	 * Creates an RGB color. Provided values have to 
	 * be in the interval [0, 255]
	 */
	Color(int r, int g, int b) {
		if(!valid(r) || !valid(g) || !valid(b))
			throw new IllegalArgumentException("invalid RGB values: " + r + ", " + g + ", " + b);
		
		this.rgb = new int[] {r, g, b};
	}

	/**
	 * Red value [0, 255]
	 */
	int getR() {
		return rgb[0];
	}

	/**
	 * Green value [0, 255]
	 */
	int getG() {
		return rgb[1];
	}

	/**
	 * Blue value [0, 255]
	 */
	int getB() {
		return rgb[2];
	}

	/**
	 * Obtains the luminance in the interval [0, 255].
	 */
	int getLuminance() {
		return (int) Math.round(rgb[0]*.21 + rgb[1]*.71 + rgb[2]*.08);
	}

	static boolean valid(int value) {
		return value >= 0 && value <= 255;
	}
//da aula 8
	static final Color Red = new Color(255, 0, 0);
	static final Color Black = new Color(0, 0, 0);
	static final Color White = new Color(255, 255, 255);
	static final Color Green = new Color(0, 255, 0);
	static final Color Blue = new Color(0, 0, 255);
	static final Color Grey = new Color(128, 128, 128);
	Color inverted (){
		return new Color(255 - getR(), 255 - getG(), 255 - getB());
	}
	static int limitar(int n, int min, int max) {
		if(n<min)
			return min;
		if(n>max)
			return max;
		else
			return n;
	}
	Color brighter(int b) {
		return new Color(limitar((getR() + b),0,255),limitar((getG() + b),0,255),limitar((getB() + b),0,255));
	}
	Color Greyer() {
		int r = getLuminance();
		return new Color(r,r,r);
	}
	boolean isEqualTo(Color c) {
		return getR() == c.getR() &&
				getG() == c.getG() &&
				getB() == c.getB();
	}
	static boolean contained(Color[] v, Color c) {
		for (int i = 0; i < v.length; i++) {
			if (c.isEqualTo(v[i]) == true)
				return true;
		}
		return false;
	}
}
