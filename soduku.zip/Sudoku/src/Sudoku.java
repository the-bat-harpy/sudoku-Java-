import java.io.PrintWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Sudoku {

	private SudokuBoard sudokuBoard;
	public ColorImage boardImage; 

//construtor

	public Sudoku(String file, int difficulty) {
		int[][] jogoSolução;
	    try {
	        File files = new File(file);
	        Scanner scanner = new Scanner(files);
	        int linhas = 0;
	        int colunas = 0;
	        
	        while (scanner.hasNextLine()) {
	            linhas++;
	            String[] linha = scanner.nextLine().split(" ");
	            colunas = linha.length; }
	        
	        scanner.close();
	        jogoSolução = new int[linhas][colunas];
	        scanner = new Scanner(files);
	        int lines = 0;
	        while (scanner.hasNextLine()) {
	            String[] rowValues = scanner.nextLine().split(" ");
	            for (int column = 0; column < colunas; column++) {
	                jogoSolução[lines][column] = Integer.parseInt(rowValues[column]); }
	            lines++;}
	        scanner.close();


		    int[][] matrizC0 = SudokuAux.MatrizSolucaoValida(jogoSolução, difficulty); //C0= com zeros
		    sudokuBoard.matrixJogo = new int[linhas][colunas];
		    for(int l=0; l<matrizC0.length; l++){
			   for(int c=0; c<matrizC0[0].length; c++){
				   sudokuBoard.getMatrixJogo()[l][c]=matrizC0[l][c];
			   }
		   }
		    sudokuBoard = new SudokuBoard(matrizC0);
		    boardImage = SudokuAux.tabuleiro(matrizC0);
		    
	    } 
	    catch(FileNotFoundException e) {
	    	System.out.println("erro ao retirar elementos do ficheiro");
	    	}
	    }

//	obrigatórias

	public void play(int[]coordenada,int valorAjogar){
		sudokuBoard.jogada(coordenada,valorAjogar);
		}
	
	public void check(){
		SudokuAux.grid(boardImage);
		SudokuAux.check(boardImage,sudokuBoard.getMatrixJogo());
	}
	
public void undo(){
	sudokuBoard.undo();
}
public int[][] help(){
	int[][]partesErradas=new int[3][9];
partesErradas[0]=sudokuBoard.segmentosErrados();
partesErradas[1]=sudokuBoard.linhasErradas();
partesErradas[2]=sudokuBoard.colunasErradas();
return partesErradas;
}

public void reset(){
	sudokuBoard.reiniciar();
	SudokuAux.grid(boardImage);
}

public boolean complete(){
	if (help().length!=0 && help()[0].length!=0){
		return false;
	}
	return true;
}

public void save(String file) {
	     try {
	    	 PrintWriter writer=new PrintWriter(new File(file));
	    	  int[][] matrixJogo=sudokuBoard.getMatrixJogo();
	    	 for(int l=0; l<matrixJogo.length; l++) {
	             for(int c=0; c<matrixJogo[0].length; c++) {
	                 writer.print(matrixJogo[l][c] + " ");
	                 }
	             writer.println(); 
	             }
	         writer.close();
	         }
	        
	     catch(FileNotFoundException e) {
	    	 System.out.println("erro ao salvar jogo");
	    	 }
	     }

public void load(String file) {
	int lines = 0;
	try {Scanner scanner=new Scanner(new File(file)) ;
        while(scanner.hasNextLine()) {
            String[] l=scanner.nextLine().split(" ");
            for (int c=0;c<l.length; c++) {
                sudokuBoard.matrixJogo[lines][c]=Integer.parseInt(l[c]);
            }
            lines++;
        }
      scanner.close();
    } 
	catch (FileNotFoundException e) {
        System.out.println("Error loading game: " + e.getMessage());
    }
}


}

