public class SudokuAux {

	static int size=396;


//	auxiliares básicos
	  static int count(int n, int []v) {
			int contagem = 0;
				for(int i=0; i < v.length; i++) {
					if (v[i]==n) {
					contagem++;
					}
					}
			return contagem;
			}
	  
	  static int[] unroll(int[][] m) {
			int []v = new int [m.length*m[0].length];
			int posicao= 0;
			for(int i=0; i< m.length; i++)
		    	for(int j=0; j< m[i].length; j++){
		    		v[posicao]=m[i][j];
					posicao++;
					}
			return v;
			}
	  
	static int randomWithout0(int max) {
		int i = (int) (Math.random() * (max));
		while(i==0){
			 i = (int) (Math.random() * (max));
			 }
		return i;
		}
	
//auxiliares	  
	 static int [] coordenadasSegmento(int segmento){
		 int []coordenadas= new int [4]; 
	 	coordenadas[0]=0;// minLinhas
		 coordenadas[1]=0;//maxLinhas
		 coordenadas[2]=0;//minColunas
		 coordenadas[3]=0;//minLinhas
		 if (segmento<=3){
			 coordenadas[1]=2; 
			 }
		  if (segmento>3 && segmento<7){
			 coordenadas[0]=3;
			 coordenadas[1]=5;
			 }
		  if (segmento>6 && segmento<10){
			 coordenadas[0]=6;
			 coordenadas[1]=8; 
			 }
		  if ((segmento+2)%3==0){
			 coordenadas[2]=0;
			 coordenadas[3]=2;
			 }
		  if ((segmento+1)%3==0){
			 coordenadas[2]=3;
			 coordenadas[3]=5;
			 }
		 if (segmento%3==0){
			 coordenadas[2]=6;
			 coordenadas[3]=8;
			 }
		 return coordenadas;
		 }
	 
	 static boolean bordasegmento(int l, int c, int índiceSegmento, int salto) {
		    int segment=(l/salto)* 3+ (c/salto)+1;
		    return segment==índiceSegmento &&
		            (l%salto==0 || l%salto==salto-1 || c%salto==0 
		            || c%salto==salto-1);
		    }
	 
	static int[] VectorColumn(int [][]matrix,int c) {
		int[] v = new int[matrix.length];
			for(int i = 0;i<matrix.length;i++) {
				v[i] = matrix[i][c];	
				}
			return v;
			}
	
 static int[] VectorLine(int[][]matrix,int l) { 				
	 int[] v = new int[matrix[0].length];
				for(int i = 0;i<matrix[0].length;i++) {
					v[i] = matrix[l][i];
					}
				return v;
				}
 
 static int[] VectorSegment(int[][] matrix, int segmento) {
	    int[] CLS = coordenadasSegmento(segmento); // CLS=coordenadasLimiteSegmento
	    int[] v = new int[matrix.length];
	    int index = 0; 
	    for (int l = CLS[0]; l <= CLS[1]; l++) { 
	        for (int c = CLS[2]; c <= CLS[3]; c++) { 
	            v[index] = matrix[l][c];
	            index++; 
	            }
	        }
	    return v;
	    }
 
static boolean repetido(int[] vector){
	int length= vector.length;
	 for (int i=0; i<length; i++){
	 if(count(vector[i],vector)!=1 &&vector[i]!=0){
		 return true;
		 }
	 }
	 return false;
	 }

 static void grid(ColorImage img){  
		for (int i=0; i<img.getHeight(); i++){ 
			for (int I=0; I<img.getWidth(); I++){
				if (I==0 || i==0 || I==img.getHeight()-1|| i==img.getWidth()-1){	//parte de fora
				img.setColor(i,I,Color.Black);}
				
				 if (I%(img.getWidth()/9)==0 && I!=0 && I!=img.getWidth()){	//todas linhas
					img.setColor(i,I,Color.Grey);}
				 
				if (i%(img.getWidth()/9)==0 && i!=0 && i!=img.getWidth()){	//todas colunas
					img.setColor(i,I,Color.Grey);}
				
				if (I%((img.getWidth()/9)*3)==0 && I!=0 && I!=img.getWidth()){	//divisão em segmentos pt1
					img.setColor(i,I,Color.Black);}
				
				if (i%(((img.getWidth()/9))*3)==0 && i!=0 && i!=img.getWidth()){	//divisão em segmentos pt1
					img.setColor(i,I,Color.Black);
					}
				}
			}
		}
 
 static void Putnumbers(ColorImage img, int [][]matrix) {
	 int []desenrolada= unroll(matrix);
	 int i=0;
	 for (int l=10; l<img.getHeight();l=l+(img.getHeight()/matrix.length) ){
		 for (int c=10; c<img.getWidth(); c=c+(img.getWidth()/matrix.length)){ //o 10 é para posicionar melhor os números
			int number=  desenrolada[i];
			 String numberString = String.valueOf(number);
			if (number==0){
				numberString= "";
				}
			i++;
			img.drawText(c,l,numberString, 20, Color.Black);
			}
		 }
	 }
 
 static boolean coordenadaVálida(int [] coordenadas,int minLine, int maxLine, int minCols, 
		 int maxCols){
	 if (coordenadas[0]<minLine || coordenadas[0]>maxLine||coordenadas[1]<minCols || 
			 coordenadas[1]>maxCols){
		 return false;
		 }
	 return true;
	 }
 
//obrigatórias
static boolean valida(int [][]matrix){
for (int i=0; i<matrix.length; i++){
if(repetido(VectorLine(matrix,i))==true||repetido(VectorColumn(matrix,i))==true||
repetido(VectorSegment(matrix,i+1))==true){
		return false;
		}
}
return true;
}

static int [][] MatrizSolucaoValida(int [][]matrix,int Quantidadezeros){
	int percentagemDeZeros=Quantidadezeros;
	int[][] matriz= new int [matrix.length][matrix[0].length];
	for (int l=0; l<matrix.length; l++){
		for (int c=0; c<matrix[0].length; c++){
			matriz[l][c]= matrix[l][c];
			}
		}
	int quantidade0=(int)((((matrix.length*matrix[0].length)*percentagemDeZeros)/100)+0.5);
	
	for (; quantidade0>0; quantidade0--){
		int linhaRand=((randomWithout0(9)));
		int colunaRand=((randomWithout0(9)));
		if (matriz[colunaRand][linhaRand]==0){ 
			quantidade0=quantidade0+1;}
	else{matriz[colunaRand][linhaRand]=0;
	}
		}
	return matriz;
	}

static String matrixTS (int[][]matrix){
	String mS = "";
	int height= matrix.length;
	int width= matrix[0].length;
for (int l = 0; l < height; l++) {
    for (int c = 0; c < width; c++) {
        mS += matrix[l][c] + " "; }
    mS += "\n";}
System.out.println(mS);
return mS;
}

static ColorImage tabuleiro (int [][]matrix){ //@colorimage 
	ColorImage tabuleiro= new ColorImage (size,size, Color.White); 
	grid(tabuleiro);
	Putnumbers(tabuleiro,matrix);
	return tabuleiro;
	}

static void changeSize(int sizeNovo){
size=sizeNovo;	
}

static void mudarPosição(int[][]matrix,int [] coordenada,int número){
matrix[coordenada[0]][coordenada[1]]=número;
}

static void linhaInválida(ColorImage img, int[][] matrix, int índiceLinha) {
    int salto=img.getHeight()/matrix.length;
    int linhaInicial=índiceLinha*salto;
    if (repetido(VectorLine(matrix, índiceLinha))) {
        for (int l =linhaInicial; l<linhaInicial+salto;l++) {
            for (int c =0; c<img.getWidth();c++) {
                if (l==linhaInicial || l==linhaInicial+salto-1 || c==0 || c==img.getWidth()-1) {
                    img.setColor(c,l,Color.Red);
                }
            }
        }
    }
}

	
static void colunaInválida(ColorImage img, int[][] matrix, int índiceColuna) {
    int salto=img.getWidth()/matrix.length;
    int colunaInicial=índiceColuna*salto;
    if (repetido(VectorColumn(matrix,índiceColuna))) {
        for (int l=0; l<img.getHeight();l++) {
            for (int c=colunaInicial; c<colunaInicial+salto;c++) {
                if (c==colunaInicial || c==colunaInicial+salto-1 || l==0 || l==img.getHeight()-1) {
                    img.setColor(c,l,Color.Red);
                }
            }
        }
    } 
}

	
static void segmentoInválido(ColorImage img,int[][]matrix, int índiceSegmento) {
	 int salto =img.getWidth()/3;
	if (repetido(VectorSegment(matrix,índiceSegmento))) {
        for (int l =0;l<img.getWidth();l++) {
            for (int c=0;c<img.getWidth();c++) {
                if (bordasegmento(l,c,índiceSegmento,salto)) {
                    img.setColor(l,c, Color.Red);
                    }
                }
            }
        }
}


static void check(ColorImage img,int[][]matrix){
	for(int i=0; i<9;i++){
		linhaInválida(img,matrix,i);
		colunaInválida (img,matrix,i);
	segmentoInválido(img,matrix,i+1);
	}
	}


}



