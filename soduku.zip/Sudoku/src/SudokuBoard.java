
public class SudokuBoard { //@colorimage

	 int[][]matrixJogo;
	 int[][]matrixoriginal;
	 int[][]jogadas;
	 int[]acabadoDeJogar; //0=coluna, 1=linha,  2=número anterior
	 int númeroJogada;

//	 adicionais, importantes para depois
	 public int[][] getMatrixJogo() {
		    return matrixJogo;
		}

	 //obrigatórias
//construtor
	 public SudokuBoard(int[][]Matrix){
		 if(SudokuAux.valida(Matrix)==false){
throw new IllegalArgumentException("matrix inválida(ou tem valores em linha repetidos, ou em colunas, ou nalgum segmento)"); }
		
		else{
			matrixJogo=new int[Matrix.length][Matrix[0].length];
			matrixoriginal=new int[Matrix.length][Matrix[0].length];
			jogadas=new int[Matrix.length][Matrix[0].length];
			acabadoDeJogar=new int[3];
			númeroJogada=0;
			
			for(int l=0; l<Matrix.length;l++){
				for(int c=0; c<Matrix[0].length;c++){
					matrixoriginal[l][c]=Matrix[l][c];
					matrixJogo[l][c]=Matrix[l][c];
					}
				}
			}
		 }

	 public int numberAtCoordinate(int[][]matrix,int []coordenada){ 
		 if (SudokuAux.coordenadaVálida(coordenada,0,matrix[0].length,0,
				 matrix.length)==false){
				throw new IllegalArgumentException("coordenada impossível (as linhas variam entre 0-8 e as colunas também)");}
		else{return matrix[coordenada[0]][coordenada[1]];
		}
		 }
	 
	 public void jogada(int [] coordenada, int valor){
		 if(numberAtCoordinate(matrixoriginal,coordenada)!=0){
				throw new IllegalArgumentException("coordenada impossível(jogada em cima de número da matrix inicial)");
			}
		 if(SudokuAux.coordenadaVálida(coordenada,0,matrixJogo[0].length,0,matrixJogo.length)==false){
				throw new IllegalArgumentException("coordenada impossível(as linhas variam entre 0-8 e as colunas também)");
			}
		 acabadoDeJogar[2]=matrixJogo[coordenada[0]][coordenada[1]];
		SudokuAux.mudarPosição(matrixJogo,coordenada,valor);
		acabadoDeJogar[0]=coordenada[0];
		acabadoDeJogar[1]=coordenada[1];
	    jogadas[númeroJogada]=acabadoDeJogar;
		númeroJogada=númeroJogada+1;
		}

public void hint(){
			int[]coordenada=new int[2];
			int quantidadedezeros=0;

			for(int l=0; l<matrixJogo.length;l++){
				for(int c=0; c<matrixJogo.length; c++){
					if(matrixJogo[c][l]==0){
						quantidadedezeros++;
						}
					}
				}
			if (quantidadedezeros==0){
				throw new IllegalStateException("não há mais posições vazias possíveis");
				}
			int [][] posiçõescomzero= new int[quantidadedezeros][2];
			int linhasdamatrix=0;
			for(int l=0; l<matrixJogo.length;l++){
				for(int c=0; c<matrixJogo.length; c++){
					if(matrixJogo[l][c]==0){
						posiçõescomzero[linhasdamatrix][0]=l;
						posiçõescomzero[linhasdamatrix][1]=c;
						linhasdamatrix++;
						}
					}
				}
			int indice=(int) (Math.random() * (posiçõescomzero.length));
			coordenada[0]=posiçõescomzero[indice][0];
			coordenada[1]=posiçõescomzero[indice][1];
			int valor=matrixoriginal[coordenada[0]][coordenada[1]]; 
			jogada(coordenada,valor);
			
			int []jogadarandom=new int[3];
			jogadarandom[0]=coordenada[0];
			jogadarandom[1]=coordenada[1];			
			jogadarandom[2]=valor;
			jogadas[númeroJogada]=jogadarandom; 
			númeroJogada=númeroJogada+1;
			}

	 public void reiniciar(){
	for(int l=0; l<matrixJogo.length; l++){
		for(int c=0; c<matrixJogo.length;c++){
			matrixJogo[l][c]=matrixoriginal[l][c];
			}
		}
	númeroJogada=0;
	}

	 public int [] segmentosErrados(){
		int quantidadeSegmentosErrados=0;
		for (int segmento=1; segmento<10;segmento++){
			if (SudokuAux.repetido(SudokuAux.VectorSegment(matrixJogo,segmento))==true){
				quantidadeSegmentosErrados++;
				}
			}
		
		int i=0;
		int [] segmentosErrados= new int[quantidadeSegmentosErrados];
		for (int segmentos=1;segmentos<10;segmentos++){
			if (SudokuAux.repetido(SudokuAux.VectorSegment(matrixJogo,segmentos))==true){
				segmentosErrados[i]=segmentos;
				i++;
				}
			}
	return segmentosErrados;
	}
	 
	 public	 int [] linhasErradas(){
		int quantidadeLinhasErradas=0;
		for (int linha=0; linha<9;linha++){
			if (SudokuAux.repetido(SudokuAux.VectorLine(matrixJogo,linha))==true){
				quantidadeLinhasErradas++;
				}
			}
		
		int i=0;
		int [] linhasErradas= new int[quantidadeLinhasErradas];
		for (int linha=0;linha<9;linha++){
			if (SudokuAux.repetido(SudokuAux.VectorLine
					(matrixJogo,linha))==true){
				linhasErradas[i]=linha;
				i++;
				}
			}
	return linhasErradas;	
}

	 public int [] colunasErradas(){
		int quantidadeColunasErradas=0;
		for (int coluna=0; coluna<9;coluna++){
			if (SudokuAux.repetido(SudokuAux.VectorColumn
					(matrixJogo,coluna))==true){
				quantidadeColunasErradas++;
				}
			}
		
		int i=0;
		int [] colunasErradas= new int[quantidadeColunasErradas];
		for (int coluna=0;coluna<9;coluna++){
			if (SudokuAux.repetido(SudokuAux.VectorLine
					(matrixJogo,coluna))==true){
				colunasErradas[i]=coluna;
				i++;
				}
			}
		
		return colunasErradas;
		}

	 public void undo(){
	númeroJogada=númeroJogada-1;
	int coluna=jogadas[númeroJogada][0];
	int linha=jogadas[númeroJogada][1];
	int valorPrévio=jogadas[númeroJogada][2];
	matrixJogo[coluna][linha]=valorPrévio;
	
	if (númeroJogada<0){
		 throw new IllegalStateException("impossível voltar atrás, está igual ao inicial");	
		 }
	}

}
